function Show-Menu {
    Clear-Host
    Write-Host "=== Menu Installation PDC ==="
    Write-Host "1. Configurer l'adresse IP"
    Write-Host "2. Installer le rôle AD DS"
    Write-Host "3. Promouvoir le serveur en contrôleur de domaine"
    Write-Host "4. Quitter"
}

do {
    Show-Menu
    $choice = Read-Host "Choisissez une option"

    switch ($choice) {
        "1" {
            $ip = Read-Host "Entrez l'adresse IP (ex: 192.168.1.101)"
            $gw = Read-Host "Entrez la passerelle (ex: 192.168.1.1)"
            $dns = Read-Host "Entrez le DNS (ex: 127.0.0.1)"
            $iface = (Get-NetAdapter | Where-Object Status -eq "Up").InterfaceAlias
            New-NetIPAddress -InterfaceAlias $iface -IPAddress $ip -PrefixLength 24 -DefaultGateway $gw
            Set-DnsClientServerAddress -InterfaceAlias $iface -ServerAddresses $dns
            Pause
        }
        "2" {
            Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools
            Pause
        }
        "3" {
            $domain = Read-Host "Nom de domaine (ex: formation.lan)"
            $netbios = Read-Host "Nom NetBIOS (ex: formation)"
            $password = Read-Host "Mot de passe DSRM"
            $secPwd = ConvertTo-SecureString $password -AsPlainText -Force
            Install-ADDSForest -DomainName $domain -DomainNetbiosName $netbios -SafeModeAdministratorPassword $secPwd -InstallDNS -Force
        }
    }
} while ($choice -ne "4")