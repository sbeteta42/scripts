$dsrmPassword = ConvertTo-SecureString "P@ssw0rd" -AsPlainText -Force

Uninstall-ADDSDomainController `
 -LocalAdministratorPassword $dsrmPassword `
 -ForceRemoval `
 -Force

Uninstall-WindowsFeature AD-Domain-Services

Remove-NetIPAddress -IPAddress "192.168.1.101" -Confirm:$false