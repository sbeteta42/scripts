$user = Read-Host "Entre alias de compte"
$password = Read-Host "Entrer le mot de passe" -AsSecureString
Set-QADUser -Identity $user -UserPassword $password
