#CONFIGURATION INTERFACE ETHERNET EN IP FIXE
New-NetIPAddress -InterfaceIndex 12 -IPAddress 192.168.42.1 -PrefixLength 24 -DefaultGateway 192.168.42.254

#Ajout de ce serveur comme DNS PRIMAIRE 
Set-DnsClientServerAddress -InterfaceIndex 12 -ServerAddresses 192.168.42.1

#DESACTIVATION DU PARE-FEU SUR TOUS LES PROFILS
Set-NetFirewallProfile -Profile * -Enabled False

#DESACTIVATION DU PARE-FEU AU NIVEAU SERVICE
C:\Windows\system32\svchost.exe -k LocalServiceNoNetwork disable

#INSTALLATION DES SERVICES ACTIVEDIRECTORY
Install-WindowsFeature -name AD-Domain-Services -IncludeManagementTools

#INSTALLATION DU DOMAINE NETBIOS + DNS
Install-ADDSDomainController -DomainName formation.lan -installDns

#Ajouter un nouveau serveur dans une nouvelle forest
Install-ADDSForest -DomainName "formation.lan"

#Installation du service DHCP
Install-WindowsFeature DHCP -IncludeManagementTools

#Pour assurer le bon fonctionnement du serveur DHCP, on cr�e le groupe de s�curit� DHCP :
Add-DhcpServerSecurityGroup

#Dans un environnement Active Directory avec un domaine, vous devez autoriser le serveur DHCP dans votre annuaire.
Add-DhcpServerInDC -DnsName srv01.formation.lan -IPAddress 192.168.42.1

