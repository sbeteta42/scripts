﻿#creation de l'étendue "formation" 
Add-DhcpServerv4Scope -EndRange 192.168.42.50 -Name "formation" -StartRange 192.168.42.1 -SubnetMask 255.255.255.0 -Type Both

#exclusion de l'adresse du serveur AD
Add-DhcpServerv4ExclusionRange -EndRange 192.168.42.1 -ScopeId 192.168.42.0 -StartRange 192.168.42.1

#Ajout du nom du domaine Microsoft AD
Add-DhcpServerInDC -DnsName “192.168.42.1”

#Configuration de l'adresse du routeur
Set-DhcpServerv4OptionValue -OptionId 3 -value 192.168.42.254

# configuration de l'option DNS
Set-DhcpServerv4OptionValue -OptionId 6 -Value 192.168.42.1

#configuration du suffixe DNS
set-DhcpServerv4Optionvalue -OptionId 15 -Value formation.lan

#Activation de l'étendue DHCP "formation"
Set-DhcpServerv4Scope -ScopeId 192.168.42 -Name "formation" -State Active
