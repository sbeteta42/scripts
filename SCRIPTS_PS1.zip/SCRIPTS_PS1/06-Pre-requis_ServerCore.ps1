#DESACTIVATION DU PARE-FEU SUR TOUS LES PROFILS
Set-NetFirewallProfile -Profile * -Enabled False

#DESACTIVATION DU PARE-FEU AU NIVEAU SERVICE
C:\Windows\system32\svchost.exe -k LocalServiceNoNetwork disable

#SUPPRESSION DE WINDOWS DEFENDER
Uninstall-WindowsFeature -Name Windows-Defender
